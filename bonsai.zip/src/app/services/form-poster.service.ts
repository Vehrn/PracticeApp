import { Injectable } from '@angular/core';
import { Bonsai } from '../models/bonsai.model';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from '../../../node_modules/rxjs';
// tslint:disable-next-line:import-blacklist
import '../../../node_modules/rxjs/Rx';
import '../../../node_modules/rxjs/add/operator/map';

@Injectable()
export class FormPoster {
    constructor(private http: Http) {

    }

    private extractData(res: Response) {
        // tslint:disable-next-line:prefer-const
        let body = res.json();
        return body.fields || {};
    }

    private handleError(error: any) {
        console.error('post error: ', error);
        return Observable.throw(error.statusText);
    }

    postNewBonsaiForm(bonsai: Bonsai): Observable<any> {
        // tslint:disable-next-line:prefer-const
        let body = JSON.stringify(bonsai);
        // tslint:disable-next-line:prefer-const
        let headers = new Headers({ 'Content-Type': 'application/json'});
        // tslint:disable-next-line:prefer-const
        let options = new RequestOptions({ headers: headers });

        return this.http.post('http://localhost:4200/postbonsai', body, options)
                        .map(this.extractData)
                        .catch(this.handleError);
        console.log('posting bonsai: ', bonsai);
    }
}
