export class Bonsai {
    constructor (
        public species: string,
        public age: number,
        public form: string,
        public outdoor: boolean,
        public potted: boolean,
        public collected: boolean,
        public location: string
    ) {  }
}
