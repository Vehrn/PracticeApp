import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Forms } from '../forms';
import { Observable } from 'rxjs';
import { Bonsai } from '../models/bonsai.model';
import { FormPoster } from '../services/form-poster.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-newbonsaiform',
  templateUrl: './newbonsaiform.component.html',
  styleUrls: ['./newbonsaiform.component.css']
})
export class NewbonsaiformComponent {
  forms: string[] = ['Broom', 'Formal Upright', 'Informal Upright', 'Slanting', 'Cascade', 'Literati'];
  locations: string[] = ['US', 'Canada', 'Japan', 'Mexico', 'China', 'EU', 'Other'];
  model = new Bonsai('', 0, 'default', false, false, false, 'default');
  hasBonsaiFormError = false;
  hasBonsaiSpeciesError = false;

  validateBonsaiForm(event) {
    if (this.model.form === 'default') {
      this.hasBonsaiFormError = true;
    } else {
      this.hasBonsaiFormError = false;
    }
  }

  validateBonsaiSpecies(event) {
    if (this.model.species === 'default') {
      this.hasBonsaiSpeciesError = true;
    } else {
      this.hasBonsaiSpeciesError = false;
    }
  }
  constructor(private formPoster: FormPoster) {}
  submitForm(form: NgForm) {
    if ( this.validateBonsaiForm(this.model.form) ) {
      return;
    }
    if ( this.validateBonsaiSpecies(this.model.species) ) {
      return;
    }

    this.formPoster.postNewBonsaiForm(this.model)
        .subscribe(
          data => console.log('success: ', data),
          err => console.log('error: ', err)
        )
  }
  reset () {}
}
