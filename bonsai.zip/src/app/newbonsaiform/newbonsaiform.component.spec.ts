import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewbonsaiformComponent } from './newbonsaiform.component';

describe('NewbonsaiformComponent', () => {
  let component: NewbonsaiformComponent;
  let fixture: ComponentFixture<NewbonsaiformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewbonsaiformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewbonsaiformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
