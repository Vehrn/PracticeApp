import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NewbonsaiformComponent } from './newbonsaiform/newbonsaiform.component';
import {  UploadModule } from './upload/upload.module';
import { FormPoster } from './services/form-poster.service';
import { HttpModule } from '../../node_modules/@angular/http';

@NgModule({
  declarations: [
    AppComponent,
    NewbonsaiformComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    UploadModule,
    HttpModule
  ],
  providers: [FormPoster],
  bootstrap: [AppComponent]
})
export class AppModule { }
