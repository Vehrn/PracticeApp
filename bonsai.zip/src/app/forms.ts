export class Forms {
    forms: string[] = ['Broom', 'Formal Upright', 'Informal Upright', 'Slanting', 'Cascade', 'Literati'];
}
